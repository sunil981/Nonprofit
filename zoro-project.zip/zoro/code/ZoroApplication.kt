package com.example.zoro

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class ZoroApplication

fun main(args: Array<String>) {
	runApplication<ZoroApplication>(*args)
}
